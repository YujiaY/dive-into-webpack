export default function show(content) {
  window.document.getElementById('app').innerText = 'Hello,' + content;
}
